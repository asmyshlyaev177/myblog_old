__version__ = u'2.6.0'
