__title__ = 'pilkit'
__author__ = 'Matthew Tretter'
__version__ = '1.1.13'
__license__ = 'BSD'
__all__ = ['__title__', '__author__', '__version__', '__license__']
