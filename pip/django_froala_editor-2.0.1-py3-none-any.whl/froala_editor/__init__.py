PLUGINS = (
    'align', 'char_counter', 'code_beautifier', 'code_view', 'colors', 'emoticons', 'entities', 'file', 'font_family',
    'font_size', 'fullscreen', 'image', 'image_manager', 'inline_style', 'line_breaker', 'link', 'lists',
    'paragraph_format', 'paragraph_style', 'quote', 'save', 'table', 'url', 'video'
)

PLUGINS_WITH_CSS = (
    'char_counter', 'code_view', 'colors', 'emoticons', 'file', 'fullscreen', 'image', 'image_manager', 'line_breaker',
    'table', 'video',
)