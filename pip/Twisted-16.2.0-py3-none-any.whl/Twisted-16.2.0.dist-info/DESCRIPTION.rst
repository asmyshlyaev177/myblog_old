An extensible framework for Python programming, with special focus
on event-based network programming and multiprotocol integration.


