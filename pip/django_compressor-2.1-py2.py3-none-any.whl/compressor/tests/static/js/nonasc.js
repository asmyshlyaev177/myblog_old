var test_value = "—";
