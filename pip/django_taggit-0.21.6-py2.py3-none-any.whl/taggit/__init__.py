VERSION = (0, 21, 6)

default_app_config = 'taggit.apps.TaggitAppConfig'
